n=input()
n=int(n)
s=input()
s = s.replace(' ','')
j=0
k=0
while(k<=n):
  if(s[k]==s[-1-k]):
    
  else:
    print('false')  
